// assertion[단언] : 타입 확정

// 1. 리액트 < > generic

const test = '메가스터디'
const mega = <string>test

//2. as(있는 게 맞음)
// const nameInput = document.querySelector('.input') as Element or HTMLInputElement(더 확정적으로 적을 수 있음)
// nameInput.(.하면 input 관련 ex value등이 나옴)

