var num = 3; //num:number에서 number생략해도 됨. 타입 추론가능
var str = 'coffee';
var n = null;
// const result = num + string
console.log(num + str);
